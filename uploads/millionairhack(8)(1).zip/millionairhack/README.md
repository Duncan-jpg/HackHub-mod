# MillionairHack

> *Millionairs are too rich — can you stop them getting richer?*

A HackHub mod with two storyline quests. No hand-holding. Players get vague clues and have to figure out the path themselves.

---

## Setup

```bash
npm install
npm run build
```

Copy the `dist/` folder and `manifest.json` into your HackHub `mods/millionairhack/` directory.

---

## Quest 1 — Jeff Lezos

**How players find it:** R3d_R0bin posts on the Hackhub feed hinting that armazon.org is more than a shop.

**Intended solve path (SPOILERS):**

1. Visit `armazon.org` or run `nslookup armazon.org` — either counts as recon.
2. Notice the armazon.org footer says *"founded 1994"* — this becomes relevant later.
3. `apt-get install mhack`, then `mhack -u armazon.org -list creds.txt`
4. mhack outputs 3 user/pass pairs. Two are decoys — only `jefflezos` actually authenticates. The jefflezos entry shows `???` for the credential, forcing players to try SSH directly and brute it.
5. `ssh -u jefflezos@<armazon_ip>` — player gets a shell.
6. Player has to explore the filesystem themselves. Wallet is on the desktop but nothing tells them that. `ls`, `ls ~/Desktop`, etc.
7. Opening the wallet file shows it's PIN-locked. The PIN is `1994` — armazon's founding year, visible on the website. Nothing in the game says this. Players have to make the connection.
8. Transfer the funds.

**Puzzle logic:**
- mhack output is shuffled each time so jefflezos isn't always in the same position
- Confidence scores are randomised so no entry looks more legitimate
- The wallet PIN is purely environmental — players must read the website

---

## Quest 2 — Zark Buckerzurg

**Unlocks after:** Jeff Lezos complete.

**Intended solve path (SPOILERS):**

1. R3d posts a hint on the feed. No details.
2. `nslookup beta.net` or visiting the site gives the IP.
3. `nmap` the IP — player sees ports 22, 80, 443, and 3306. Port 3306 (mysql) is a **dead end red herring**.
4. SSH as user `beta` with a blank password — this is the anonymous foothold. Nothing tells the player this exists. They have to try common usernames with no password.
5. Once in, `cat /etc/passwd` or `ls /home` reveals a `zark` user account.
6. The password for `zark` is NOT in any credential dump. Player must find `/etc/beta/backup.conf` which contains a plaintext backup credential: `w3_4r3_c0nn3ct3d`.
7. `ssh -u zark@<beta_ip>` — player is now in Zark's account.
8. Nothing on the surface looks interesting. Player must run `ls -la` to reveal the hidden `.private` directory.
9. Reading files in `.private` completes the find objective and triggers R3d's second mail, which hints (but doesn't say explicitly) that Zark has an internal email address and wouldn't want these files made public.
10. Player has to find Zark's email address themselves (it's in `/etc/beta/users.conf`) and send him a mail.

**Puzzle logic:**
- Port 3306 is a deliberate dead end to waste time
- The blank-password `beta` account is unintuitive — players must experiment
- Zark's password is leet-speak for "we are connected" — discoverable only by reading config files on the machine
- `ls -la` vs `ls` matters — hidden directory only shows with the flag

---

## Terminal Command — mhack

Install: `apt-get install mhack`  
Usage: `mhack -u <url> -list <outfile>`

Only works against `armazon.org`. Returns 3 candidates, shuffled, with randomised confidence scores. The real account (`jefflezos`) has its password hidden — forces SSH trial-and-error.

---

## Websites

| Host | Style |
|------|-------|
| `armazon.org` | Green Amazon parody selling hacking items. Footer contains the 1994 founding year clue. |
| `beta.net` | Red Meta parody social network. Trending topics include `#ZarkLeaks`. |
