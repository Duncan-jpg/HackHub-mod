import { Command, RegisterCommand, Events, Storage } from "@hotbunny/hackhub-content-sdk";

@RegisterCommand
export class MhackCommand extends Command {

    CommandName = "mhack";
    Description = "Network user enumeration tool";
    PackageName = "mhack";

    Autocomplete = [
        { label: "mhack", type: "STRING" as const },
        { label: "-u", type: "STRING" as const },
        { label: "<url>", type: "DOMAIN" as const },
        { label: "-list", type: "STRING" as const },
        { label: "<output file>", type: "STRING" as const },
    ];

    async Run(tools) {
        const { flags } = tools.parseFlags();

        if (!flags.u) {
            tools.printError("mhack: missing required flag -u");
            tools.println("usage: mhack -u <url> [-list <outfile>]");
            return;
        }

        const url = flags.u as string;
        const outfile = flags.list as string | undefined;

        tools.println(`mhack v2.1.0 — network user enumeration`);
        tools.newLine();
        tools.println(`target: ${url}`);
        tools.println(`resolving host...`);
        await tools.sleep(900);

        const knownTargets = ["armazon.org", "www.armazon.org"];
        if (!knownTargets.includes(url.toLowerCase())) {
            tools.printError(`host unreachable or does not expose an enumerable endpoint`);
            tools.println(`tip: mhack only works against targets with a discoverable web surface`);
            return;
        }

        tools.println(`enumerating user accounts...`);
        await tools.sleep(1400);
        tools.println(`probing SSH banner...`);
        await tools.sleep(800);
        tools.println(`correlating web session artifacts...`);
        await tools.sleep(1100);
        tools.newLine();

        // Read the real password that the quest stored in a Variable
        const realPassword = Storage.get("JeffSSHPassword") ?? "hunter2";
        const decoyPass = "Xk#9mP2r!vQw";

        const entries = [
            { user: "j.lezos",   pass: decoyPass    },
            { user: "jefflezos", pass: realPassword  },
            { user: "admin",     pass: decoyPass     },
        ];

        // Shuffle so jefflezos isn't always in the same position
        entries.sort(() => Math.random() - 0.5);

        tools.printTable(
            ["#", "user", "credential_hint", "confidence"],
            entries.map((e, i) => [
                String(i + 1),
                e.user,
                e.pass,
                `${Math.floor(60 + Math.random() * 35)}%`,
            ])
        );

        tools.newLine();
        tools.printWarning(`3 candidate accounts found. confidence scores are estimates only.`);

        if (outfile) {
            tools.printSuccess(`results written to ~/${outfile}`);
        }

        Events.emit("MillionairHack.MhackRan", { url } as any);
    }

}
