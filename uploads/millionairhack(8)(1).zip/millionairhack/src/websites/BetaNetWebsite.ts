import { Website, RegisterWebsite } from "@hotbunny/hackhub-content-sdk";
import homePage from "./pages/betanet-home.html";

@RegisterWebsite
export class BetaNetWebsite extends Website {

    SiteName = "beta.net";
    Host = "beta.net";
    Icon = "";
    Popular = true;

    Pages = [
        {
            path: "/",
            title: "beta.net - Connect with the World",
            description: "The world's largest social network. beta.net connects billions of people.",
            html: homePage,
            seo: true,
            search: ["beta.net", "social network", "connect", "buckerzurg"],
        },
    ];

}
