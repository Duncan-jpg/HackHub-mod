import { Website, RegisterWebsite, Network } from "@hotbunny/hackhub-content-sdk";
import homePage from "./pages/armazon-home.html";

@RegisterWebsite
export class ArmazonWebsite extends Website {

    SiteName = "Armazon";
    Host = "armazon.org";
    Icon = "";
    Popular = true;

    Pages = [
        {
            path: "/",
            title: "Armazon - The Hacker's Marketplace",
            description: "Buy and sell hacking tools, exploits, and tutorials on armazon.org.",
            html: homePage,
            seo: true,
            search: ["armazon", "hacking tools", "exploits", "marketplace"],
        },
    ];

    Exports = {
        getServerIp: () => {
            const subnet = Network.getSubnetByDomain("armazon.org");
            return subnet?.ip ?? "unavailable";
        },
    };

}
