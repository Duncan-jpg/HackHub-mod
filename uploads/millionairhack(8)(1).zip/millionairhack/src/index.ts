import { Bootstrap, RegisterModPackage } from "@hotbunny/hackhub-content-sdk";
import "./quests/JeffLezosQuest";
import "./quests/ZarkBuckerzurgQuest";
import "./websites/ArmazonWebsite";
import "./websites/BetaNetWebsite";
import "./commands/MhackCommand";

@RegisterModPackage
export default class MillionairHack extends Bootstrap {

    OnModPackageLoaded() {
        console.log("MillionairHack loaded! Time to take down the ultra-rich.");
    }

    OnModPackageUnloaded() {
        console.log("MillionairHack unloaded.");
    }

}
