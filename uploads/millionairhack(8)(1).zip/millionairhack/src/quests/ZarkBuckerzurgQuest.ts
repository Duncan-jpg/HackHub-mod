import { Quest, RegisterQuest, Network, Random } from "@hotbunny/hackhub-content-sdk";

interface ZarkBuckerzurgData {
    betaNetIp: string;
    zarkPassword: string;
    decoyPassword: string;
}

@RegisterQuest
export class ZarkBuckerzurgQuest extends Quest<ZarkBuckerzurgData> {

    Name = "ZarkBuckerzurg";
    Title = "Zark Buckerzurg";
    Description = "R3d has another job. No details yet.";
    Group = "storyline" as const;
    Rewards = { money: 750000, xp: 1500 };
    MaxClaim = 1;
    AutoStart = true;
    QuestsToComplete = ["JeffLezos"];

    Objectives = [
        {
            name: "find-server",
            description: "Locate the beta.net server",
        },
        {
            name: "get-in",
            description: "Get into the file system",
            unlocksAfter: ["find-server"],
        },
        {
            name: "find-zark-account",
            description: "There's a user on this machine you really want. Find them.",
            unlocksAfter: ["get-in"],
        },
        {
            name: "login-as-zark",
            description: "Get into that account.",
            unlocksAfter: ["find-zark-account"],
        },
        {
            name: "find-the-goods",
            description: "Look around. Something here is worth having.",
            unlocksAfter: ["login-as-zark"],
        },
        {
            name: "leverage",
            description: "Make it worth your while.",
            unlocksAfter: ["find-the-goods"],
        },
    ];

    Mails = [
        {
            title: "next one",
            content: `beta.net.\n\nyou know what to do by now.\n\n- R`,
        },
        {
            title: "interesting reading, isn't it",
            content: `whatever you found in there... zark wouldn't want that getting out.\n\nhe has a personal email on the system. i'd write him a letter.\n\n- R`,
        },
    ];

    CreateData(): ZarkBuckerzurgData {
        return {
            betaNetIp: Network.randomIp(),
            zarkPassword: "w3_4r3_c0nn3ct3d",
            decoyPassword: Random.password(),
        };
    }

    OnStart() {
        Network.registerDomain("beta.net", this.Data.betaNetIp);
        Network.createSubnetNetwork({
            ip: this.Data.betaNetIp,
            type: Network.Type.Router,
            domain: { name: "beta.net" },
            ports: [
                { external: 22,   internal: 22,   active: true, service: "ssh"   },
                { external: 80,   internal: 80,   active: true, service: "http"  },
                { external: 443,  internal: 443,  active: true, service: "https" },
                { external: 3306, internal: 3306, active: true, service: "mysql" },
            ],
            users: [
                Network.createUser({ username: "beta",  password: "" }),
                Network.createUser({ username: "zark",  password: this.Data.zarkPassword }),
                Network.createUser({ username: "admin", password: this.Data.decoyPassword }),
            ],
            children: [],
        });
        this.sendMail(0);
    }

    OnObjectivesStart() {
        // find-server: whois on beta.net
        this.Events.on("Terminal.Whois", (data) => {
            if (data.domain === "beta.net") {
                this.completeObjective("find-server");
            }
        });

        // get-in: any SSH connect to beta.net IP
        this.Events.on("Terminal.FTP.Connect", (ip) => {
            if (ip === this.Data.betaNetIp) {
                this.completeObjective("get-in");
            }
        });

        // find-zark-account: player uses dirhunter to enumerate the server
        this.Events.on("Terminal.Dirhunter", (data) => {
            if (data.ip === this.Data.betaNetIp) {
                this.completeObjective("find-zark-account");
            }
        });

        // login-as-zark: SSH connected AND username is zark
        // We track this by checking SSH.Connected after get-in is done
        // and zark account was found — use Network.UserActivity
        this.Events.on("Network.UserActivity", (data) => {
            if (data.ip === this.Data.betaNetIp && data.username === "zark") {
                this.completeObjective("find-zark-account"); // complete in case they skipped dirhunter
                this.completeObjective("login-as-zark");
            }
        });

        // find-the-goods: player downloads a file via SSH
        this.Events.on("Files.Transfer", (data) => {
            if (data.ip === this.Data.betaNetIp) {
                this.completeObjective("find-the-goods");
                this.sendMail(1);
            }
        });

        // also catch cat on the remote machine
        this.Events.on("Terminal.Cat", (data) => {
            if (data.filename?.toLowerCase().includes("private") ||
                data.filename?.toLowerCase().includes("personal") ||
                data.filename?.toLowerCase().includes("secret")) {
                this.completeObjective("find-the-goods");
                this.sendMail(1);
            }
        });

        // leverage: player receives a reply from zark after sending mail
        this.Events.on("Mail.Received", (data) => {
            if (data.from?.toLowerCase().includes("zark") ||
                data.subject?.toLowerCase().includes("zark")) {
                this.completeObjective("leverage");
            }
        });
    }

    OnComplete() {
        Network.removeDomain("beta.net");
        Network.destroyNetwork(this.Data.betaNetIp);
    }

    OnAbandon() {
        Network.removeDomain("beta.net");
        Network.destroyNetwork(this.Data.betaNetIp);
    }
}
