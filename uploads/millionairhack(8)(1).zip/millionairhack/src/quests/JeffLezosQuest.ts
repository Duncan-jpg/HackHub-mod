import { Quest, RegisterQuest, Network, Random, Storage } from "@hotbunny/hackhub-content-sdk";

interface JeffLezosData {
    armazonIp: string;
    sshPassword: string;
    decoyPassword1: string;
    decoyPassword2: string;
}

@RegisterQuest
export class JeffLezosQuest extends Quest<JeffLezosData> {

    Name = "JeffLezos";
    Title = "Jeff Lezos";
    Description = "Someone left you a cryptic message. Might be worth looking into.";
    Group = "storyline" as const;
    Rewards = { money: 500000, xp: 1000 };
    MaxClaim = 1;
    AutoStart = true;

    Objectives = [
        {
            name: "recon",
            description: "Learn something about armazon.org",
        },
        {
            name: "run-mhack",
            description: "You'll need the right tools. Find them, install them, use them.",
            unlocksAfter: ["recon"],
        },
        {
            name: "get-in",
            description: "Get access to the armazon.org server",
            hint: "Try FTP with the credentials from mhack",
            unlocksAfter: ["run-mhack"],
        },
        {
            name: "find-wallet",
            description: "There's something valuable on that machine. Find it.",
            unlocksAfter: ["get-in"],
        },
        {
            name: "transfer",
            description: "Move the money somewhere safe.",
            unlocksAfter: ["find-wallet"],
        },
    ];

    Mails = [
        {
            title: "...",
            content: `you didn't hear this from me.\n\narmazon.org isn't just a shop. look closer.\n\n- R`,
        },
        {
            title: "found something?",
            content: `so you found the wallet.\n\nthe PIN is 4 digits. lezos is predictable. think about what he cares about most.\n\ncheck his public profiles if you need a nudge.\n\n- R`,
        },
    ];

    CreateData(): JeffLezosData {
        return {
            armazonIp: Network.randomIp(),
            sshPassword: Random.password(),
            decoyPassword1: Random.password(),
            decoyPassword2: Random.password(),
        };
    }

    OnStart() {
        Network.registerDomain("armazon.org", this.Data.armazonIp);
        Network.createSubnetNetwork({
            ip: this.Data.armazonIp,
            type: Network.Type.Router,
            domain: { name: "armazon.org" },
            ports: [
                { external: 21, internal: 21, active: true, service: "ftp" },
                { external: 80, internal: 80, active: true, service: "http" },
            ],
            users: [
                Network.createUser({ username: "jefflezos", password: this.Data.sshPassword }),
                Network.createUser({ username: "j.lezos",   password: this.Data.decoyPassword1 }),
                Network.createUser({ username: "admin",     password: this.Data.decoyPassword2 }),
            ],
            children: [],
        });
        // Store the real SSH password so mhack can read it
        Storage.set("JeffSSHPassword", this.Data.sshPassword);
        this.sendMail(0);
    }

    OnObjectivesStart() {
        // Recon: player opens armazon.org in the browser
        this.Events.on("Browser.WebsiteOpened", (data) => {
            if (data.url?.includes("armazon.org")) {
                this.completeObjective("recon");
            }
        });

        // run-mhack: player runs the mhack command against armazon.org
        this.Events.on("Terminal.Command", (data) => {
            if (data.command === "mhack") {
                this.completeObjective("run-mhack");
            }
        });

        // get-in: SSH connected — payload is just the IP string
        this.Events.on("Terminal.FTP.Connect", (ip) => {
            if (ip === this.Data.armazonIp) {
                this.completeObjective("get-in");
            }
        });

        // find-wallet: player downloads a file via SSH containing "wallet"
        this.Events.on("Files.Transfer", (data) => {
            if (data.ip === this.Data.armazonIp && data.filename?.toLowerCase().includes("wallet")) {
                this.completeObjective("find-wallet");
                this.sendMail(1);
            }
        });

        // also catch if player uses cat to read the wallet file
        this.Events.on("Terminal.Cat", (data) => {
            if (data.filename?.toLowerCase().includes("wallet")) {
                this.completeObjective("find-wallet");
                this.sendMail(1);
            }
        });

        // transfer: bank transfer
        this.Events.on("Bank.Transfer", (data) => {
            if (data.amount > 0) {
                this.completeObjective("transfer");
            }
        });
    }

    OnComplete() {
        Network.removeDomain("armazon.org");
        Network.destroyNetwork(this.Data.armazonIp);
    }

    OnAbandon() {
        Network.removeDomain("armazon.org");
        Network.destroyNetwork(this.Data.armazonIp);
    }
}
